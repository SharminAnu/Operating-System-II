/* initialize.c - nulluser, sysinit */

#include <conf.h>
#include <kernel.h>
#include <proc.h>
#include <sem.h>
#include <sleep.h>
#include <mem.h>
//#include <tty.h>
#include <q.h>
#include <io.h>
//#include <disk.h>
//#include <network.h>

//extern	int	main();			/* address of user's main prog	*/
void main_fun();
void end_game();
void proc(int *);
void procA(int *);
void procB(int *);
void procC(int *);


/* Declarations of major kernel variables */

struct	pentry	proctab[NPROC]; /* process table			*/
int	nextproc;		/* next process slot to use in create	*/
struct	sentry	semaph[NSEM];	/* semaphore table			*/
int	nextsem;		/* next semaphore slot to use in screate*/
struct	qent	q[NQENT];	/* q table (see queue.c)		*/
int	nextqueue;		/* next slot in q structure to use	*/
int	*maxaddr;		/* max memory address (set by sizmem)	*/
#ifdef	NDEVS
struct	intmap	intmap[NDEVS];	/* interrupt dispatch table		*/
#endif
struct	mblock	memlist;	/* list of free memory blocks		*/
#ifdef	Ntty
//struct  tty     tty[Ntty];	/* SLU buffers and mode control		*/
#endif

sigset_t full_block, full_unblock;
ucontext_t posix_ctxt_init, end_game_ctxt;

/* active system status */

int	numproc;		/* number of live user processes	*/
int	currpid;		/* id of currently running process	*/
int	reboot = 0;		/* non-zero after first boot		*/

#ifdef	RTCLOCK
extern int clkruns;			
#endif

int	rdyhead,rdytail;	/* head/tail of ready list (q indexes)	*/
char	vers[] = VERSION;	/* Xinu version printed at startup	*/

/************************************************************************/
/***				NOTE:				      ***/
/***								      ***/
/***   This is where the system begins after the C environment has    ***/
/***   been established.  Interrupts are initially DISABLED, and      ***/
/***   must eventually be enabled explicitly.  This routine turns     ***/
/***   itself into the null process after initialization.  Because    ***/
/***   the null process must always remain ready to run, it cannot    ***/
/***   execute code that might cause it to be suspended, wait for a   ***/
/***   semaphore, or put to sleep, or exit.  In particular, it must   ***/
/***   not do I/O unless it uses kprintf for polled output.           ***/
/***								      ***/
/************************************************************************/

/*------------------------------------------------------------------------
 *  nulluser  -- initialize system and become the null process (id==0)
 *------------------------------------------------------------------------
 */

int up=0;
LOCAL sysinit();
void idle_thread();
void main_fun(int *);

//void nulluser()				/* babysit CPU when no one home */

int main(int argc, char *argv[])
{
	int	userpid, main_fun_cnt;
	sigset_t ps;

	main_fun_cnt = 1;

	sigfillset(&full_block);
	sigemptyset(&full_unblock);

	/*kprintf("\n\nXinu Version %s", vers);
	if (reboot++ < 1)
		kprintf("\n");
	else
		kprintf("   (reboot %d)\n", reboot); */
	
	if(getcontext(&posix_ctxt_init) == -1){
        perror("getcontext failed in initialize.c ");
        exit(5);
    }
	sysinit();			/* initialize all of Xinu */

	end_game_ctxt = posix_ctxt_init;
	end_game_ctxt.uc_stack.ss_sp    = (void *)((long)getstk(MINSTK)-MINSTK+1);
	end_game_ctxt.uc_stack.ss_size  = MINSTK;
	end_game_ctxt.uc_stack.ss_flags = 0;
	makecontext(&end_game_ctxt, end_game, 0);


	/*kprintf("%u real mem\n",(unsigned)maxaddr+(unsigned)sizeof(int));
	kprintf("%u avail mem\n",
		(unsigned)maxaddr-(unsigned)(&end)+(unsigned)sizeof(int));
	kprintf("clock %sabled\n\n", clkruns==1?"en":"dis");*/
	
	//enable();			/* enable interrupts */

	/* create a process to execute the user's main program */
	int main_args[] = {main_fun_cnt};
	up = userpid = create(main_fun, INITSTK, INITPRIO, INITNAME, INITARGC, main_args);
	if (up == SYSERR) perror("error on create\n");
/* #ifdef	NETDAEMON
	/* start the network input daemon process */
	//resume(
	//  create(NETIN, NETISTK, NETIPRI, NETINAM, NETIARGC, userpid)
//	);
//#else
//	resume( userpid );
//#endif

//	while (TRUE) {			/* run forever without actually */
//		pause();		/*  executing instructions	*/
//	} */

setcontext (&(proctab[NULLPROC].posix_ctxt));

write(1,"\nBAD THINGS ARE HAPPENING\n",26);

	return;				/* unreachable			*/
}

/*------------------------------------------------------------------------
 *  sysinit  --  initialize all Xinu data structures and devices
 *------------------------------------------------------------------------
 */
LOCAL	sysinit()
{
	int	i;
	struct	pentry	*pptr;
	struct	sentry	*sptr;
	struct	mblock	*mptr;

	numproc  = 0;			/* initialize system variables */
	nextproc = NPROC-1;
	nextsem  = NSEM-1;
	nextqueue= NPROC;		/* q[0..NPROC-1] are processes */

	memlist.mnext = mptr =		/* initialize free memory list */
	  (struct mblock *) malloc(FREE_SIZE);
	if(mptr == NULL){
		perror("malloc failed ");
		exit(3);
	}

	end = (unsigned long) mptr;
	maxaddr = (void*)((unsigned long)mptr + (unsigned long)(FREE_SIZE) + 1L);

	mptr->mnext = (struct mblock *)NULL;
//	mptr->mlen = truncew((unsigned long)maxaddr-NULLSTK-(unsigned long)&end);
	mptr->mlen = truncew((FREE_SIZE)-(NULLSTK)); 

	for (i=0 ; i<NPROC ; i++)	/* initialize process table */
		proctab[i].pstate = PRFREE;

	pptr = &proctab[NULLPROC];	/* initialize null process entry */
	pptr->pstate = PRCURR;
	pptr->pprio = 0;
	for(i = 0; i<7; ++i){
		pptr->pname[i] = *("prnull" + i);
	}
	//strcpy(pptr->pname, "prnull");
	pptr->plimit = ((long)mptr + (FREE_SIZE) - (NULLSTK) -1);
	pptr->pbase = (long)mptr + (FREE_SIZE) -1;
	*( (int *)(pptr->pbase -3)) = MAGIC;
	pptr->paddr = idle_thread;
	pptr->phasmsg = FALSE;
	pptr->pargs = 0;
	pptr->posix_ctxt = posix_ctxt_init;

	pptr->posix_ctxt.uc_stack.ss_sp = (void *)pptr->plimit;
	pptr->posix_ctxt.uc_stack.ss_size = NULLSTK;
	pptr->posix_ctxt.uc_stack.ss_flags = 0;
	pptr->posix_ctxt.uc_link = &end_game_ctxt;
	
	makecontext(&pptr->posix_ctxt, idle_thread, 0);

	currpid = NULLPROC;

	for (i=0 ; i<NSEM ; i++) {	/* initialize semaphores */
		(sptr = &semaph[i])->sstate = SFREE;
		sptr->sqtail = 1 + (sptr->sqhead = newqueue());
	}

	rdytail = 1 + (rdyhead=newqueue());/* initialize ready list */

#ifdef	MEMMARK
	_mkinit();			/* initialize memory marking */
#endif
#ifdef	RTCLOCK
	clkinit();			/* initialize r.t.clock	*/
#endif
#ifdef	Ndsk
	dskdbp= mkpool(DBUFSIZ,NDBUFF);	/* initialize disk buffers */
	dskrbp= mkpool(DREQSIZ,NDREQ);
#endif
//	for ( i=0 ; i<NDEVS ; i++ )	/* initialize devices */
//		init(i);
	return(OK);
}

void idle_thread(){
	int i = 1, j;
	enable();
	while(1){
		write(1, "#", 1);
		if(i){
			if(resume(up)==SYSERR) perror("error on resume\n");
			i = 0;
		}
		resched();
		for(j = 0; j<1000000000; j++);
	}
}

void main_fun(int *arg){
	int i, j=0, k, gig_count, lcount;
	char *name = "tproc";
	int sem1, pidA, pidB, pidC, main_pid;

	main_pid = getpid();
	write(1, "\nMAIN: main function is alive\n", 30);

	if((sem1 = screate(0)) == SYSERR){
		write(1, "\nsem create failed\n", 19);
	}

	int argA[] = {sem1};
	if((pidA = create(procA, MINSTK, 20, name, 1, argA)) == SYSERR){
		write(1, "\ncreate A failed\n", 17);
	}
	int argB[] = {sem1, pidA};
	if((pidB = create(procB, MINSTK, 20, name, 2, argB)) == SYSERR){
		write(1, "\ncreate B failed\n", 17);
	}
	
	int argC[] = {main_pid, 30};
	if((pidC = create(procC, MINSTK, 20, name, 2, argC)) == SYSERR){
		write(1, "\ncreate C failed\n", 17);
	}

	write(1, "\nMAIN: main function has created procs A B and C\n", 49);
	write(1, "\nMAIN: main function about to suspend self\n", 43);

	if(resume(pidA) == SYSERR ||
		resume(pidB) == SYSERR ||
		resume(pidC) == SYSERR ){
			write(1, "\nmain resume of A B and C failed\n", 33);
		}

	if(suspend(main_pid) == SYSERR){
		write(1, "\nmain suspend failed\n", 21);	
	}
	write(1, "\nMAIN: main is awake and counting\n", 43);
	gig_count = lcount = 0;
	while (gig_count<10)
	{
		if(++lcount<0){
			++gig_count;
			lcount = 0;
		}
	}
	write(1, "\nMAIN: main function finished, goodbye\n", 39);
	
}

void end_game(){
	write(1, "<>", 2);
	kill(getpid());
}

void procA(int *args){
	int arg = args[0];
	write(1, "\nA: process A is alive\n", 22);
	write(1, "\nA: process A is about to wait on a sem\n", 39);

	if(wait(arg) == SYSERR){
		write(1, "\nin A wait failed\n", 18);
	}
	write(1, "\nA: process A is awake from sem, will wait for msg\n", 51);

	if(receive() == SYSERR){
		write(1, "\nin A receive failed\n", 21);
	}
	write(1, "\nA: process A has received a msg, goodbye\n", 42);

}

void procB(int *args){
	int arg1= args[0], arg2 = args[1];
	write(1, "\nB: process B is alive\n", 22);
	write(1, "\nB: process B is about to sleep for 2 seconds\n", 45);

	if(sleep(2) == SYSERR){
		write(1, "\nin B sleep failed\n", 19);
	}
	write(1, "\nB: process B is awake from sleep, will signal sem\n", 51);

	if(signal(arg1) == SYSERR){
		write(1, "\nin B signal failed\n", 20);
	}
	write(1, "\nB: process B is again to sleep for 2 seconds\n", 46);

	if(sleep(2) == SYSERR){
		write(1, "\nin B sleep2 failed\n", 20);
	}
	write(1, "\nB: process B is awake from sleep, will send msg to A\n", 54);

	if(send(arg2, 111) == SYSERR){
		write(1, "\nin B msg send failed\n", 22);
	}
	write(1, "\nB: process B is about to sleep for 2 seconds\n", 46);

	if(sleep(2) == SYSERR){
		write(1, "\nin B sleep3 failed\n", 20);
	}
	write(1, "\nB: process B is awake from sleep, goodbye\n", 43);

}

void procC(int *args){
	int arg1 = args[0], arg2 = args[1];
	write(1, "\nC: process C is alive\n", 22);
	write(1, "\nC: process C is about to sleep for 30 seconds\n", 48);

	if(sleep(arg2) == SYSERR){
		write(1, "\nin C sleep failed\n", 19);
	}
	write(1, "\nC: process C is awake from sleep, will resume main\n", 52);

	if(resume(arg1) == SYSERR){
		write(1, "\nin C resume failed\n", 20);
	}
	write(1, "\nC: process C is finished, goodbye\n", 35);

}

void proc(int *args){
	int arg = args[0];
	int i, j=0;
	char msg[] = {' ', 'P', 'R', 'O', 'C', '\0', ' '};

	msg[5] = 48+arg;
	write(1,msg,7);
	if(arg == 4)sleep(2);
	for(i=1; i<100000001; ++i){
		if((i+1)%25000000 == 0)write(1, &msg[5], 1);
	}
	write(1,msg,7);
}



