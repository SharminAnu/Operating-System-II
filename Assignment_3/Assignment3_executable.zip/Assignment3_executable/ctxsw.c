/* ctxsw.c - ctxsw

/*------------------------------------------------------------------------
/* ctxsw  --  actually perform context switch, saving/loading registers
/*------------------------------------------------------------------------*/
#include <kernel.h>

void ctxsw(ucontext_t *context_A, ucontext_t *context_B ){
	
	swapcontext(context_A, context_B);

	return;
}
