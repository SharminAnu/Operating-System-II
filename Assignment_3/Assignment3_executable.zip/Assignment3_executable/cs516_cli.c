#include <stdio.h>
#include <conf.h>
#include <kernel.h>
#include <proc.h>
#include <sem.h>
#include <sleep.h>
#include <mem.h>
//#include<tty.h>
#include <q.h>
#include <io.h>

#define         SHOW       1
#define         SUSPEND    2
#define         RESUME     3
#define         KILL       4
#define         CREATE     5
#define         PROC       6
#define         RDY        7
#define         SLP        8
#define         WTR        9
#define         RCV       10
#define         LOOP      11
#define         PROMPT    15
#define         INTEG     25
#define         JUNK      26
#define         LABEL 	  27
#define		    STR       29
#define		    EXIT	  30
#define		    SIGNAL	  31
#define		    CMDS	  32

void    procRCV(void);
void    procSLP(int);
void    procWRT(int);
void    procLOOP(void);

char obuf[100];

#define lprintf0(fmt)  sprintf(obuf, fmt); \
                            write(1, obuf, strlen(obuf))
#define lprintf1(fmt, a1)  sprintf(obuf, fmt, a1); \
                                write(1, obuf, strlen(obuf))
#define lprintf2(fmt, a1, a2)  sprintf(obuf, fmt, a1, a2); \
                                write(1, obuf, strlen(obuf))
#define lprintf3(fmt, a1, a2, a3)  sprintf(obuf, fmt, a1, a2, a3); \
                                write(1, obuf, strlen(obuf))

extern int yylex(void);
extern char * yytext;

typedef struct{ 
    int state;
    void *getmem_adr;
    int size;
}MEMALLOC;

extern MEMALLOC memarray[500];
extern int memarray_max;
int iglobal = 0;


int cli_main(){

    int tok, i, j, k, secs, sem, delta = 0;
    unsigned short temp;
    char *pstr = NULL;

    lprintf0("\nCommand Interpreter Ready\n\n");
    lprintf0("enter cmd> ");

    while(tok = yylex()){
        switch (tok)
        {
        case SHOW:
            switch (tok=yylex())
            {
            case PROC:
                lprintf0("\n IN SHOW PROC\n");
                for(j=0; j<NPROC; ++j){
                    switch (proctab[j].pstate)
                    {
                    case PRCURR: pstr = "CURRENT";
                        break;
                    case PRFREE: pstr = "FREE";
                        break;
                    case PRREADY: pstr = "READY";
                        break;
                    case PRRECV: pstr = "RECVWAITING";
                        break;
                    case PRSLEEP: pstr = "SLEEPING";
                        break;
                    case PRSUSP: pstr = "SUSPENDED";
                        break;
                    case PRWAIT: pstr = "SEMWAITING";
                        break;                    
                    default:
                        break;
                    }
                    lprintf3("\nProc %d State %s Priority %d\n", j, pstr, proctab[j].pprio );

                }
                break;
            case SLP:
                lprintf0("\n IN SHOW SLP");
                k = q[clockq].qnext;
                for(j=0; j<NPROC; ++j){
                    if(k<NPROC){
                        lprintf2("\n Proc %d Wait Ticks %d\n", k, q[k].qkey);
                        k=q[k].qnext;
                    }
                    else break;
                }
                break;
            case RDY:
                lprintf0("\n IN SHOW RDY\n");
                k = q[rdytail].qprev;
                for(j=0; j<NPROC; ++j){
                    if(k<NPROC){
                        lprintf2("\n Proc %d Priority %d\n", k, q[k].qkey);
                        k=q[k].qprev;
                    }
                    else break;

                }
                break;
            case CMDS:
                lprintf0("CLI commands are: \n");
                lprintf0("SHOW:\tFollowing Commands are Valid after Show:\n");
                lprintf0("\t\tPROC:\t Show the proc table\n");
                lprintf0("\t\tSLP:\t Show the proc in Sleep Queue\n");
                lprintf0("\t\tRDY:\t Show the proc in Ready Queue\n");
                lprintf0("\t\tCMDS:\t Show all Commands\n");
                lprintf0("SUSPEND:\tSuspend the proc with PID given after this command\n");
                lprintf0("RESUME:\tResume the proc with PID given after this command\n");
                lprintf0("KILL:\tKill the proc with PID given after this command\n");
                lprintf0("EXIT:\tExit CLI and Xinu\n");
                lprintf0("CREATE:\t Create a proc. Following Commands are valid after CREATE:\n");
                lprintf0("\t\tRCV:\t Create a proc in Recieve state\n");
                lprintf0("\t\tSLP:\t Create a proc in Sleep sleep\n");
                lprintf0("\t\tWTR:\t Create a proc in wait state\n");
                lprintf0("\t\tLOOP:\t Create a proc who run a large loop\n");
                break;
            default:
                lprintf1("\nBad Operand after SHOW is %s\n", yytext);
                break;
            }
            break;
        case SUSPEND: 
            switch (tok=yylex())
            {
            case INTEG:
                lprintf1("\n IN SUSPEND with PID %s \n", yytext);
                if(suspend(atoi(yytext)) == SYSERR){
                    lprintf1("\nSuspend failed for pid %s \n", yytext);
                }
                break;

            default:
                lprintf1("\nBad operand after SUSPEND is %s \n", yytext);
                break;
            }
            break;

        case RESUME: 
            switch (tok=yylex())
            {
            case INTEG:
                lprintf1("\n IN RESUME with PID %s\n", yytext);
                if(resume(atoi(yytext)) == SYSERR){
                    lprintf1("\nResume failed for pid %s\n", yytext);
                }
                break;
            default:
                lprintf1("\n Bad operand after RESUME is %s \n", yytext);
                break;
            }
            break;
        case KILL:
            switch (tok=yylex())
            {
            case INTEG:
                lprintf1("\n IN KILL with PID %s \n", yytext);
                if(kill(atoi(yytext))== SYSERR){
                    lprintf1("\n kill failed for pid %s \n", yytext);
                }
                break;
            default:
                lprintf1("\n Bad operand after KILL is %s \n", yytext);
                break;
            }
            break;
        case EXIT:
            lprintf0("\n COMMAND LINE INTERPRETER IS DONE, GOODBYE \n");
            exit(5);
            break;
        case CREATE:
            switch (tok=yylex())
            {
            case RCV:
                lprintf0("\n IN CREATE WITH RCV\n");
                if(create(procRCV, MINSTK, 15, "RCV", 0) == SYSERR){
                    lprintf0("\n Create with RCV failed\n");
                }
                break;
            case SLP:
                lprintf0("\n IN CREATE WITH SLP\n");
                secs = 120;
                if(create(procSLP, MINSTK, 15, "SLP", 1, secs) == SYSERR){
                    lprintf0("\n Create with SLP failed\n");
                }
                break;
            case WTR:
                lprintf0("\n IN CREATE WITH WTR\n");
                if((sem = screate(0)) == SYSERR){
                    lprintf0("\n sem create failed\n");
                }
                if(create(procWRT, MINSTK, 15, "WTR", 1, sem) == SYSERR){
                    lprintf0("\n create with WTR failed \n");
                }
                break;
            case LOOP:
                lprintf0("\n IN CREATE with LOOP \n");
                if(create(procLOOP, MINSTK, 15, "LOOP", 0) == SYSERR){
                    lprintf0("\n create with LOOP failed\n");
                }
                break;
            default:
                lprintf1("\n Bad operand after CREATE is %s \n", yytext);
                break;
            }
        default:
            break;
        }
        sleep(1);
        lprintf0("\nenter cmd> ");
    }


}
void procRCV(void){
    lprintf1( "RCV proc is alive with pid %d\n", getpid());
    int msg = receive();
    lprintf1( "RCV recieved msg %d and now done, goodbye\n", msg);
    return;
}

void procSLP(int slp){
    lprintf1( "SLP:\tsleep proc is alive with pid %d\n", getpid());
    lprintf1( "SLP:\tsleep will to sleep for %d seconds\n", slp);
    sleep(slp);
    lprintf0( "SLP has awakened, is now done, goodbye\n");
    return;
}

void procWRT(int sem){
    lprintf1("WTR proc is alive with pid %d\n", getpid());
    lprintf1("WTR will now wait on semophore %d\n", sem);
    wait(sem);
    return;
}

void procLOOP(void){
    int i,j;
    for(i=0; i<10000; i++){
        write(1,'L',1);
        for(j=0; j< 1000; j++ );
    }
    return;
}