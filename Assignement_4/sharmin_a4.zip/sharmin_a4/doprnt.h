#ifndef ___doprnt_h
#define ___doprnt_h

#include <stdarg.h> /* POSIX */

void _doprnt(const char *fmt,
             va_list args,
	     int (*func) (int fd, char c),
	     int farg);

#endif
