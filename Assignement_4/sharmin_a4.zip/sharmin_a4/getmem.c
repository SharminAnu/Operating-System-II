/* getmem.c - getmem */

#include <conf.h>
#include <kernel.h>
#include <mem.h>

/*------------------------------------------------------------------------
 * getmem  --  allocate heap storage, returning lowest integer address
 *------------------------------------------------------------------------
 */
VSYSCALL	*getmem(unsigned long nbytes)
{
	sigset_t	ps;
	struct	mblock	*p, *q, *leftover;

	disable(ps);
	if (nbytes==0 || memlist.mnext==NULL) {
		restore(ps);
		return( (int *)SYSERR);
	}
	nbytes = (unsigned long) roundew(nbytes);
	for (q= &memlist,p=memlist.mnext ; p!=NULL ; q=p,p=p->mnext)
		if ( p->mlen == nbytes) {
			q->mnext = p->mnext;
			restore(ps);
			return( (int *)p );
		} else if ( p->mlen > nbytes ) {
			leftover = (struct mblock *)( (unsigned long)p + nbytes );
			q->mnext = leftover;
			leftover->mnext = p->mnext;
			leftover->mlen = p->mlen - nbytes;
			restore(ps);
			return( (int *)p );
		}
	restore(ps);
	return( (int *)SYSERR );
}

/* round_12  using 12 byte header free list, need round 12 all allocs    
    */

unsigned round_12(unsigned req_size){
unsigned modval;

if((modval = req_size%12) == 0)return req_size;
else
return (req_size + (12 - modval));
}


/* trunc_12  using 12 byte header free list, need trunc 12 orig space    
    */

unsigned trunc_12(unsigned free_space_size){
unsigned modval;

if((modval = free_space_size%12) == 0)return free_space_size;
else
return (free_space_size - modval);
}