#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <sys/types.h>
#include <unistd.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <termio.h>
#include <errno.h>
#include <signal.h>

/** include one of the endian headers below **/
/** depending on system your using          **/

/** #include <sys/endian.h> **/
#include <endian.h>

#define  DEVCONIN		0
// #define  SHKEY	 	 15643779
#define  SHKEY           10293948
#define  DEVCONOUT		1
#define  INBUFSIZE	      500

/********
#define  HIGHWTRMRK	       40
#define  LOWWTRMRK	       20
#define  O_NONBLOCK    0x00000040
********/

typedef struct {
	union{
	  ushort	RCSR;
	  struct {
#if BYTE_ORDER == LITTLE_ENDIAN
                ushort          :6;
                ushort  int_enbl:1;
                ushort      done:1;
                ushort          :8;
#else

		ushort		:8;
		ushort      done:1;
		ushort  int_enbl:1;
		ushort		:6;
#endif
	  }rcsr_bit;
	}rcsr;
        union{
          ushort        RBUF;
          struct {
#if BYTE_ORDER == LITTLE_ENDIAN
                ushort      byte:8;
                ushort          :4;
                ushort    parity:1;
                ushort      fram:1;
                ushort      ovfl:1;
                ushort       err:1;
#else

                ushort       err:1;
                ushort      ovfl:1;
                ushort      fram:1;
                ushort    parity:1;
                ushort          :4;
                ushort      byte:8;
#endif
          }rbuf_bit;
        }rbuf;
        union{
          ushort        XCSR;
          struct {
#if BYTE_ORDER == LITTLE_ENDIAN
                ushort       brk:1;
                ushort          :5;
                ushort  int_enbl:1;
                ushort      done:1;
                ushort          :8;
#else

                ushort          :8;
                ushort      done:1;
                ushort  int_enbl:1;
                ushort          :5;
                ushort       brk:1;
#endif
          }xcsr_bit;
        }xcsr;
        union{
          ushort        XBUF;
          struct {
#if BYTE_ORDER == LITTLE_ENDIAN
                ushort      byte:8;
                ushort          :8;
#else

                ushort          :8;
                ushort      byte:8;
#endif
          }xbuf_bit;
        }xbuf;
  } CSR_TYPE;

extern int errno;

