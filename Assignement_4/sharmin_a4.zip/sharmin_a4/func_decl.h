/* func_decl.h  include declarations of all functions */

extern int newqueue();
extern int insert();
extern int dequeue();
extern int resched();
extern int write();
extern int wakeup();
// extern static int newpid();
extern int clkinit();
extern int resume();
extern int create(void (*procaddr)(),  /* procedure address       */
                int ssize,      /* stack size in words          */
                int priority,   /* process priority > 0         */
                char *name,     /* name (for debugging)         */
                int nargs,      /* number of args that follow   */
                ...);           /* more args possible           */
extern int getpid();
extern int getc();
extern int screate();
extern int suspend();
extern int kill();
extern int wait();
extern int receive();
extern int sleep();
extern int signal();
extern int send();
extern int freemem();
extern void *getmem();
extern int getlast();
// extern static int newsem();
extern int count();
extern int sdelete();
extern int getfirst();
extern int ready();
extern int insertd();
extern int sleep10();
extern int stopclk();
extern int enqueue();
extern int init();
extern int scount();
extern int signaln();
extern int sreset();
extern int sdelete();
extern int iosetvec();
