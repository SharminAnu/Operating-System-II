#include "ttem_endian_port.h"


int		shmid;
char		*shm_addr;
CSR_TYPE 	*csr;
char		buffer[INBUFSIZE];
int 		buf_used=0;
int		in=0,out=0;
int		in_int_cnt=0, out_int_cnt=0;

void	iint(int sig)
{
  ++in_int_cnt;
  if(buf_used < (INBUFSIZE - 1)){
	buffer[in] = csr->rbuf.rbuf_bit.byte;
        in = (in + 1)%INBUFSIZE;
	csr->rcsr.rcsr_bit.done = 0;
	++buf_used;
  }else
	csr->rcsr.rcsr_bit.done = 0;
 if(buf_used == 1){
   // wake up the transmitter in case it's quiesced
   csr->xcsr.xcsr_bit.int_enbl = 1;
   csr->xcsr.xcsr_bit.done = 0;
  }
}

void	oint(int sig)
{
  ++out_int_cnt;
  if(buf_used != 0){
	csr->xbuf.xbuf_bit.byte = buffer[out];
	--buf_used;
	out = (out + 1)%INBUFSIZE;
	csr->xcsr.xcsr_bit.done = 1;
   }else{
	// quiesce the transmitter if no more output
	csr->xcsr.xcsr_bit.int_enbl = 0;
	csr->xcsr.xcsr_bit.done = 0;
   }
}
	
void	term_handler(int sig)
{
  printf("\n\n    EMULATOR ISRs GOING DOWN ON SIGTERM\n\n");
  printf("Number input signals: %d,  Number output signals: %d\n\n",
			in_int_cnt,			out_int_cnt);
  exit(sig);
}


int	main(int argc, char *argv[])
{

  int		i,j,k;
  struct 	sigaction new;
  sigset_t      mask_sigs;

  sigfillset(&mask_sigs);

  new.sa_handler = iint;
  new.sa_mask    = mask_sigs;
  new.sa_flags   = SA_RESTART;

  if(sigaction(SIGUSR1, &new, (struct sigaction *)0) == -1){
	perror("sigaction iint error");
	exit(1);
  }

  new.sa_handler = oint;
  new.sa_mask    = mask_sigs;
  new.sa_flags   = SA_RESTART;


  if(sigaction(SIGUSR2, &new, (struct sigaction *)0) == -1){
	perror("sigaction oint error");
	exit(1);
  }

  new.sa_handler = term_handler;
  new.sa_mask    = mask_sigs;
  new.sa_flags   = SA_RESTART;


  if(sigaction(SIGTERM, &new, (struct sigaction *)0) == -1){
	perror("sigaction term_handler error");
	exit(1);
  }

  printf("my pid is %d \n", getpid() );
  if((shmid = shmget(SHKEY, 4096, IPC_CREAT | 0600)) == -1){
        perror("shmget error");
        exit(1);
  }

  if((shm_addr = shmat(shmid, 0, 0)) == (char *)-1){
        perror("shmat error");
        exit(1);
  }

   csr = (CSR_TYPE *)shm_addr;
   csr->rcsr.rcsr_bit.done = 0;
   csr->rcsr.rcsr_bit.int_enbl = 1;
   csr->xcsr.xcsr_bit.int_enbl = 1;
   csr->xcsr.xcsr_bit.done = 0;

	
  while(1){
	pause();
  }
}


