/* ioint.s - inint, outint */

#include <conf.h>
#include <kernel.h>
#include <io.h>

/*----------------------------------------
* ioint -- Interrupt Dispatch Management
*------------------------------------------
*/

void ioint(int sig_num){
	int descrp = CONSOLE;
	// struct devsw *devptr;
	struct intmap *map;

	map = &intmap[descrp];

	switch(sig_num){
		case SIGUSR1: map->iin(map->icode);
						break;
		case SIGUSR2: map->iout(map->ocode);
						break;
	}
}

